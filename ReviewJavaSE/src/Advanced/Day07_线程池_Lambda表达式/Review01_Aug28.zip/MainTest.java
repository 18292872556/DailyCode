package Advanced.Day07_线程池_Lambda表达式.Review01_Aug28;


import com.sun.security.jgss.GSSUtil;

import java.util.concurrent.locks.ReentrantLock;

/**
 * Created with IntelliJ IDEA 2024.1.4.
 * jdk 17.0.12
 *
 * @Authur: xuexuezi
 * @Date: 2026/08/28/下午4:10
 * @Description:
 */
public class MainTest {
    // Day06 线程、同步、线程状态练习题
// 要求：每题独立完成；题目只给要求，不给实现步骤。
// 避免重复考察同一个知识点或完全相同的代码写法，并覆盖本章主要知识点。
    /*齐思： 接口重写实现都用Lambda*/

// 01. 继承Thread创建线程
// 自定义线程类，接收线程名称并重写run()。
// 启动线程后输出线程名称和0~9，观察main线程与子线程的执行顺序。
    /*第一次执行结果是先main的而且是全部执行完
    * 第二次是交错输出*/
private static void demo01(){
    Thread t1 = new Thread(() -> {
        for(int i = 0; i < 10; i++){
            System.out.println(i);
        }
    });

    t1.start();

    //main线程
    for(int i = 11; i < 20; i++){
        System.out.println(i);
    }

}

// 02. 使用Thread构造方法创建带名称的线程
// 使用Runnable作为任务，并通过Thread(Runnable,String)指定线程名称。
// 在线程中输出当前线程名称以及一段任务信息。
    private static void demo02(){
        Thread t1 = new Thread(() -> System.out.println("demo02的runnable重写run方法"), "demo02线程");
        t1.start();
}

// 03. 验证start()与run()的区别
// 创建一个线程对象，分别观察直接调用run()和调用start()时的执行效果。
// 要求通过输出当前线程名称判断代码究竟由哪个线程执行。
    /*这个还真不知道区别，课件里好像没讲start和run的区别
    * 看输出好像没什么区别*/
    private static void demo03(){
        Thread t1 = new Thread(() -> {
            System.out.println("demo03重写run的信线程,观察run和start方法区别");
            /*只能通过输出当前线程名来区分区别,run是输出main，start输出才是demo03线程。
            * 说明run只是作为一个普通方法被调用，没有创建线程*/
            System.out.println(Thread.currentThread().getName());
        },"demo03线程");

        t1.run();
        t1.start();
    }

// 04. 获取当前线程对象
// 在线程任务中分别使用getName()和Thread.currentThread()获取线程信息。
// 输出“线程名称：xxx，线程对象：xxx”，观察Thread对象字符串中的信息。
    private static void demo04(){
        System.out.println("线程名称：" + Thread.currentThread().getName());
        System.out.println("线程对象：" + Thread.currentThread());
    }
    //输出结果，直接输出线程对象，就是Thread[]的格式，括号里三个分别是线程名，优先级和线程所属的组
    //其中优先级10最大最优先，最低1，一般都是5
    //线程名称：main
    //线程对象：Thread[main,5,main]

// 05. 使用匿名内部类创建两个不同任务的线程
// 不单独定义Runnable实现类，直接创建两个线程并分别指定不同任务。
// 要求两个线程名称不同，并让两个任务同时开始执行。
    /*感觉和Day06考察的好像差不多？主要应该是多了Lambda和线程池，速战速决吧*/
    private static void demo05(){
        Thread t1 = new Thread(() -> {
            System.out.println("run() -> demo05线程1在run");
        },"demo05线程1");
        Thread t2 = new Thread(() -> {
            System.out.println("run() -> demo05线程2在run");
        },"demo05线程2");
        t1.start();
        t2.start();
    }

// 06. 使用同一个Runnable对象创建两个线程
// 创建一个Runnable任务对象，再使用它创建两个Thread线程。
// 在任务中维护一个成员变量并输出变化，观察两个线程是否共享该Runnable对象的数据。
    private static void demo06(){
        Runnable r = new Demo06Runnable();
        Thread t1 = new Thread(r);
        Thread t2 = new Thread(r);
        t1.start();
        t2.start();
    }
    /*这里写的是count < 10才++,如果是共同维护一个那不会超过10
    * 因为没写同步，也就是可能超过10，但不会太多。不会到20，来验证他两在维护同一个数据
    * 但跑了好几次都没有超过10，也没有重复+的情况，只是每次输出的顺序不同，思考为什么没有同步出错
    * 比如t1对count读到是9，然后准备++被抢夺线程，然后t2读到发现是9,满足条件准备++结束是10，
    * 然后回到t1，因为刚刚被抢的位置是count++，继续++应该就会是11，为什么这里没出过这种线程安全问题？
    *
    * 跑了好几次都没看出来问题，还以为没问题。所以是线程太短，操作没同步但也太短了，刚好没有被抢的分开过*/

// 07. 验证sleep()作用于当前线程
// 创建线程A，让A在执行过程中sleep 2秒；main线程不要sleep。
// 输出A睡眠前后的信息，观察sleep期间main线程是否仍能继续执行。
    /*验证了前后main都是RUNNABLE可运行状态*/
    private static void demo07(){
        System.out.println("main:" + Thread.currentThread().getName());//输出main的状态
        System.out.println("main" + Thread.currentThread().getState());

        Thread A = new Thread(() -> {
            try{
                Thread.sleep(2000);
            }catch(InterruptedException e){
                e.printStackTrace();
            }
        },"线程A");
        A.start();

        System.out.println("main" + Thread.currentThread().getName());//输出main的状态
        System.out.println("main" + Thread.currentThread().getState());
        /* ● 疑惑： 怎么获取到main的名字直接访问状态？万一此刻获取的线程不是main是A呢？*/

    }

// 08. 设计一个简单的“交错执行”效果
// 创建两个线程分别循环输出A0~A9和B0~B9，并在循环中加入短暂sleep。
// 不要求严格交替，只观察两个线程是否会出现交错执行。
    /*不睡眠就不交替，睡眠了就交替*/
    private static void demo08(){
        Thread t1 = new Thread(() -> {
            for(int i = 0; i < 10; i++){
                try{
                    Thread.sleep(3000);
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
                System.out.println("A" + i);//别写''会无法拼接，直接计算了
            }
        }, "demo08的A线程");
        Thread t2 = new Thread(() -> {

            for(int i = 0; i < 10; i++){
                try{
                    Thread.sleep(3000);
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
                System.out.println("B" + i);
            }
        }, "demo08的B线程");

        t1.start();
        t2.start();

    }

// 09. 制造线程安全问题
// 使用一个Runnable对象保存100张票，创建三个窗口线程同时卖票。
// 故意不加同步控制，观察是否可能出现重复售票或卖出不存在的票。
    /*有重复的，还有不存在的0和-1*/
    private static void demo09(){
        Runnable runnable = new Demo09Runnable();
        Thread t1 = new Thread(runnable, "窗口1");
        Thread t2 = new Thread(runnable, "窗口2");
        Thread t3 = new Thread(runnable, "窗口3");
        t1.start();
        t2.start();
        t3.start();
    }

// 10. 验证共享资源的竞态问题
// 创建两个线程操作同一个共享计数器，分别执行1000次count++。
// 运行多次并观察最终结果，思考为什么结果可能小于预期值。
    private static void demo10(){
//        Runnable r = new Runnable(){
//            private int count;
//            @Override
//            public void run() {
//                for(int i = 0; i < 1000; i++){
//                    count++;
//                };
//            }
//        };
//
//        Thread t1 = new Thread(r, "demo10线程1");
//        Thread t2 = new Thread(r, "demo10线程2");
//        t1.start();
//        t2.start();
        /*因为这里要求的是两个线程操作同一个共享计数器，既然共享了，就不存在分别执行1000次count，
        而是共同执行1000次所以结果？等下，好像并不是这道题的思路。重写*/
        Demo10Runnable r1 = new Demo10Runnable();
        Demo10Runnable r2 = new Demo10Runnable();
        Thread t1 = new Thread(r1, "demo10线程1");
        Thread t2 = new Thread(r2, "demo10线程2");
        /*这里把Demo10Runnable里的count定义为static类型，这样r1，r2就共享这个资源，但是因为
        * 是不同的对象，所以操作也是独立进行，可以完成分别+1000的任务，而不是合在一起+1000次*/
        t1.start();
        t2.start();
        //因为这里调试r1的count老是0，r2的老是2000。怀疑是检测的太早了count在线程里还没加完
        //睡眠一下等两个线程走完，捕获到了1697
        try{
            Thread.sleep(3000);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
        System.out.println("r1最终的count：" + r1.getCount());
        System.out.println("r2最终的count：" + r2.getCount());

        /*分析为什么最后结果可能小于2000,因为count++不是一个原子操作，不是不可分割的
        * 没有写同步的话，就是两个线程抢CPU抢来抢去，可能t1线程刚刚读到count刚刚读取到是0，然后准备+1,
        * 就被t2线程抢走了然后t2那边读到count=0,+1结果是1。回到t1其实这个时候count已经是1了
        * 但是因为被抢之前t1读到的count是0，所以+1后依然记得是1.等于白+*/
    }

// 11. 使用同步代码块解决售票问题
// 在共享票数基础上，用synchronized代码块保护“判断+修改”操作。
// 三个线程共同售卖100张票，要求不能出现重复票和负数票。
    private static void demo11(){
//        Runnable r1 = () -> {
//
//        };哦不能这样写，因为有成员变量
        Runnable runnable = new Runnable(){
            private int count = 100;
            Object lock = new Object();
            @Override
            public void run() {
                synchronized(lock){
                    while(count > 0){
                        try{
                            Thread.sleep(1000);//模拟出票时间3s
                        }catch(InterruptedException e){
                            e.printStackTrace();
                        }
                        System.out.println(Thread.currentThread().getName() +
                                "正在卖：" + count--);
                    }
                }

            }
        };

        Thread t1 = new Thread(runnable, "窗口1");
        Thread t2 = new Thread(runnable, "窗口2");
        Thread t3 = new Thread(runnable, "窗口3");
        t1.start();
        t2.start();
        t3.start();
    }

// 12. 使用指定锁对象保护共享资源
// 创建一个独立Object作为锁，两个线程访问同一个共享计数器。
// 要求同步代码块使用同一个锁对象，验证两个线程是否能互斥执行。
    private static void demo12(){
        /*首先思考，怎么验证互斥执行，就是不会互相抢占？
        还是用count++来验证，一个+的时候另一个无法访问就无法拆分，可以正常的加够*/
        Runnable runnable = new Runnable(){
            int count = 0;
            @Override
            public void run() {
                synchronized(this){
                    for(int i = 0; i < 10; i++){
                        System.out.println(Thread.currentThread().getName() +
                                "的count：" + ++count);
                    }
                }
            }
        };

        Thread t1 = new Thread(runnable, "demo12线程1");
        Thread t2 = new Thread(runnable, "demo12线程2");

        t1.start();
        t2.start();
        //System.out.println("" + runnable.count);count无访问为什么
        /*因为Runnable接口没有count，变量都看左*/
    }

// 13. 观察不同锁对象的效果
// 创建两个内容相同但不是同一个对象的锁，让两个线程分别使用它们同步。
// 在同步代码块中sleep一段时间，观察两个线程是否仍可能同时执行。
    /*咋观察是不是同时执行呢？同步里写的循环输出，如果同时进行，
    输出就是不是一次性循环完。而是中间被穿插另一个线程的输出。就这样验证吧
    原来指的是不用同一个锁对象，那应该也可以互斥，因为要锁里的进行完，sleep也不会释放锁*/
    static String str1 = new String("123");
    static String str2 = new String("123");//这样的创建方式就不是同一个对象
    private static void demo13(){
        Runnable r1 = new Runnable() {
            @Override
            public void run() {
                synchronized(str1){
                    try{
                        Thread.sleep(1000);
                    }catch(InterruptedException e){
                        e.printStackTrace();
                    }
                    for(int i = 0; i < 10; i++){
                        System.out.println(i);
                    }
                }
            }
        };
        Runnable r2 = new Runnable() {
            Object lock = new Object();
            @Override
            public void run() {
                synchronized(str2){
                    try{
                        Thread.sleep(1000);
                    }catch(InterruptedException e){
                        e.printStackTrace();
                    }
                    for(int i = 0; i < 10; i++){
                        System.out.println(i);
                    }
                }
            }
        };

        Thread t1 = new Thread(r1, "demo13线程1");
        Thread t2 = new Thread(r1, "demo13线程2");
        t1.start();
        t2.start();
    }

// 14. 使用synchronized实例方法
// 创建共享Runnable对象，将修改共享数据的操作封装为synchronized实例方法。
// 创建多个线程调用该方法，验证实例方法隐含的锁对象是谁。
    private static int count = 0;
    private  static synchronized void counter(){
        System.out.println(Thread.currentThread().getName() + "进入");
        try{
            Thread.sleep(1000);
        }catch(InterruptedException e){
            e.printStackTrace();
        }
        for(int i = 0; i < 10; i++){
            System.out.println(count++);//每个线程都分别+10次
        }
        //之前的写法错误判断，只能输出当前线程名
        //要判断同步方法隐含的锁对象是不是this，可以写一个同步代码块锁对象为this，观察互斥和Bolcked情况


    }
    private static void demo14(){
        /*咋验证实力方法隐含的锁对象？一般实例同步方法的锁就是类对象本身this，
        static类型的锁对象就是类名.class。到时候输出一下正在运行的线程名就行*/
        Runnable r1 = () ->{
            counter();
        };
        Runnable r2 = new Runnable() {
            @Override
            public void run() {
                synchronized(this){
                    System.out.println("同步代码块获取到this锁：");
                }
            }

        };

        Thread t1 = new Thread(r1, "demo14线程1");
        Thread t2 = new Thread(r1, "demo14线程2");
        Thread t3 = new Thread(r1, "demo14线程3");
        Thread t4 = new Thread(r2, "demo14线程4");
        t1.start();
        t4.start();
        System.out.println("同步代码块状态：" + t4.getState());
        System.out.println("同步方法状态：" + t1.getState());//只要有一个BLOCKED就说明同步方法用的是this作为锁对象
        //也是成功捕获到了！
//        t2.start();
//        t3.start();
    }

// 15. 使用static synchronized方法
// 创建static共享计数器，并使用static synchronized方法修改它。
// 使用多个线程调用该方法，思考static同步方法锁住的是哪个对象。
    /*是类名.class*/
    private static int flag = 0;
    private static synchronized void flager(){
        for(int i = 0; i < 10; i++){
            System.out.println(flag++);
        }
        //和上一个一样，也是错误判断，正确判断是用同步代码块带着锁互斥
        //System.out.println("锁对象：" + Thread.currentThread().getName());
    }
    private static void demo15(){
        Runnable runnable = () -> flager();
        Thread t1 = new Thread(runnable, "demo15线程1");
        Thread t2 = new Thread(runnable, "demo15线程2");
        Thread t3 = new Thread(runnable, "demo15线程3");
        Thread t4 = new Thread(){
            @Override
            public void run(){
                for(int j = 0; j < 10; j++){
                    synchronized(MainTest.class){
//                    try{
//                        Thread.sleep(1000);
//                    }catch(InterruptedException e){
//                        e.printStackTrace();
//                    }
                        System.out.println("同步代码块获取锁");
                        for(int i = 0; i < 10; i++){
                            System.out.println(flag++);
                        }
                    }
                }

            }
        };

        t1.start();
        t2.start();
        t4.start();
        //获取到同步代码块（MainTest.class)的状态： BLOCKED
        //说明另外两个线程用的锁对象就是MainTest.class
        //静态同步方法的状态：RUNNABLE


        System.out.println("静态同步方法的状态：" + t1.getState());
        System.out.println("同步代码块（MainTest.class)的状态：" + t4.getState());
//        t3.start();
    }

// 16. 对比实例同步方法与静态同步方法
// 分别创建实例同步方法和static同步方法，并让线程同时调用。
// 通过注释说明两者的锁对象分别是什么，并判断两者是否使用同一把锁。
    /*前面两道已经验证过了，同步方法的锁对象是this对象，静态同步方法的锁对象是类名.class
    * 怎么用代码判断两者是否使用同一把锁？得看一个走的时候另一个是不是会BLOCKED
    * 但这道题的要求是要线程同时调用这两个方法，就无法判断方法的状态，不懂这题这句啥意思
    * 又是出的不严谨吧?或者把两个方法写到不同的对象里，然后判断是不是有阻塞的情况？
    * 但阻塞的状态又不一定百分百捕捉到，算了反正已经知道了就不写了*/
    private synchronized static void syn01(){
        /*static的锁对象是类名.class*/
        //System.out.println("static同步方法的锁对象是：" + Thread.currentThread().getName());
        //错误写法

        System.out.println("静态同步方法");
    }
    private synchronized  void syn02(){
        /*实例方法的锁对象是 this 就是new MainTest()*/
        //System.out.println("static同步方法的锁对象是：" + Thread.currentThread().getName());
        //错误判断
        System.out.println("同步方法");
    }
    private static void demo16(){
        Runnable runnable = () -> {
            syn01();
            new MainTest().syn02();
        };

        Thread t1 = new Thread(runnable);
        t1.start();
    }

// 17. 使用ReentrantLock解决线程安全
// 使用ReentrantLock保护共享票数，多个线程共同卖票。
// 要求正确调用lock()和unlock()，观察加锁后的执行效果。
    private static void demo17(){
        ReentrantLock lock = new ReentrantLock();//一定记得写线程外面
        Runnable runnable = new Runnable() {
            int count = 20;
            @Override
            public void run() {
                //ReentrantLock lock = new ReentrantLock();
                //锁对象写在这个位置的话，多个线程之间无法共享
                //因为每个线程都会创建一个独立的锁对象
                lock.lock();
                while(count > 0){
                    try{
                        Thread.sleep(3000);
                    }catch(InterruptedException e){
                        e.printStackTrace();
                    }
                    System.out.println(Thread.currentThread().getName() + "正在卖："
                    + count--);
                }
                lock.unlock();
            }
        };

        Thread t1 = new Thread(runnable, "窗口1");
        Thread t2 = new Thread(runnable, "窗口2");
        Thread t3 = new Thread(runnable, "窗口3");
        t1.start();
        t2.start();
        t3.start();
    }

// 18. 对比Lock与synchronized
// 使用ReentrantLock改写一个同步代码块中的临界区。
// 在注释中说明Lock需要显式加锁、释放锁，而synchronized由语法结构管理锁。
   // 就是把 synchronized { 共享数据操作 } 这种同步代码块，改写成 Lock.lock() +
// try { 共享数据操作 } finally { Lock.unlock() }。
    /*这题目没啥意义，直接改成包子铺和吃包子算了*/
    private static void demo18(){
        /*不懂啥意思，问了出题gpt给出了新的解释。就是要finally*/
        //因为上节20题的等待唤醒很费时间，写的很差。这里也不知道要写什么案例，所以这里复刻一次
        //按照包子铺和吃包子的食客来写这个互相的等待唤醒，要求是做一个包子就吃一个
        //没有多余的囤积
        //并且把同步方法改成lock锁，在finally多加一层保险。防止出现异常不释放锁对象
//        BaoZi bz = new BaoZi("");
//        Thread 包子铺 = new Thread(() -> {
//
//        });
//        Thread 食客 = new Thread(() -> {
//
//        });

        Demo18BaoZi bz = new Demo18BaoZi();
        Demo18BaoZiPu baoZiPu = new Demo18BaoZiPu(bz);
        Demo18ShiKe shiKe = new Demo18ShiKe(bz);
        baoZiPu.start();
        shiKe.start();

    }

// 19. 观察NEW与RUNNABLE状态
// 创建线程但先不要启动，输出它的状态；调用start()后再尝试观察状态。
// 必要时在run()中加入sleep，让RUNNABLE状态更容易被观察。
    private static void demo19(){

//        Thread t2 = new Thread(() -> {
//            for(int i = 0; i < 10; i++){
//                System.out.println("t1的状态 ：" + Thread.currentThread().getState());
//            }
//        }, "demo19线程2");
        Thread t1 = new Thread(() -> {
            for(int i = 0; i < 10; i++){
                System.out.println(i);
            }
        }, "demo19线程1");
        //不启动t1的情况下，又要观察她的状态，只能用另一个线程来观察她的状态并输出
//        t2.start();
        System.out.println("t1启动前状态：" + t1.getState());
        t1.start();
        System.out.println("t1启动后状态：" + t1.getState());

        //调试，捕获不到new一直是runnable
    }

// 20. 观察TIMED_WAITING状态
// 创建一个线程，在run()中调用Thread.sleep(3000)。
// 使用另一个线程持续观察目标线程状态，记录其进入TIMED_WAITING以及之后恢复的状态。
    /*什么叫之后恢复的状态，恢复什么？终止了恢复什么*/
    private static void demo20(){
        Thread t1 = new Thread(() -> {
            try{
                Thread.sleep(3000);
            }catch(InterruptedException e){
                e.printStackTrace();
            }
        }, "线程1");
        Thread t2 = new Thread(() -> {
            for(int i = 0; i < 10; i++){
                System.out.println("demo20t1的状态：" + t1.getState());
            }
        }, "线程2");
        t2.start();
        t1.start();
    }

// 21. 观察BLOCKED状态
// 让线程A持有同一个锁并sleep较长时间，再让线程B尝试进入该同步代码块。
// 使用第三个线程观察B的状态，尽可能捕获B处于BLOCKED的时刻。
    static Object obj = new Object();
    private static void demo21(){
        Thread A = new Thread(()->{
            synchronized(obj){
                try {
                    Thread.sleep(5000);
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
            }
        }, "A");

        Thread B = new Thread(()->{
            synchronized(obj){
                System.out.println("B获取到同步锁");
            }
        }, "B");

        Thread C = new Thread(()->{
            long begin = System.currentTimeMillis();
            //优化了观察时间，还要优化输出不重复
            Thread.State lastState = null;
            while(true){
                Thread.State state = B.getState();
                if(state != lastState){
                    System.out.println("B的状态：" + state);
                    lastState = state;
                }
                long end = System.currentTimeMillis();
                if(end - begin > 500){
                    break;
                }
            }//因为只想输入一段时间不想一直无限循环，考虑有没有计时器类似的写法

        }, "C，观察B的线程");

        C.start();
        A.start();
        B.start();
    }

// 22. 理解sleep与锁的关系
// 让线程A在synchronized代码块中sleep 3秒，同时让线程B尝试获取同一把锁。
// 观察A睡眠时是否仍然持有锁，并记录B的状态变化。
    /*怎么观察A睡眠时是否仍然持有锁？同时检测他两的状态,B获取不到就说明A还持有锁
    * 也就是也要捕获到B的BLOCKED状态*/
    private static void demo22(){
        Thread A = new Thread(()->{
            synchronized(obj){
                try{
                    Thread.sleep(3000);
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
                System.out.println("A睡醒了");
            }
        }, "线程A");
        Thread B = new Thread(()->{
            synchronized(obj){
                System.out.println("B获取到锁");
            }
        }, "线程B");

        Thread C = new Thread(()->{
            long end = System.currentTimeMillis() + 3000;
            Thread.State AlastState = null;
            Thread.State BlastState = null;
            while(System.currentTimeMillis() < end){
//                System.out.println("A的状态：" + A.getState());
//                System.out.println("B的状态：" + B.getState());
                Thread.State state = A.getState();
                Thread.State state2 = B.getState();
                if(state != AlastState){
                    System.out.println("A的状态" + state);
                    AlastState = state;
                }
                if(state2 != BlastState){
                    System.out.println("B的状态" + state2);
                    BlastState = state2;
                }
//                long time = System.currentTimeMillis();
//                if(end - begin > 500){
//                    break;
//                }
            }

        }, "线程C");

        A.start();
        B.start();
        C.start();
        //结果：
        //A的状态TIMED_WAITING
        //B的状态BLOCKED
        //A睡醒了
        //B获取到锁
        //疑惑为什么A会先TIMED_WAITING然后又睡醒？难道
        //哦哦是计时等待不是结束，正确的

    }


// 23. 使用wait()进入WAITING
// 创建两个线程共享同一个锁，线程A在同步代码块中调用wait()。
// 使用另一个线程观察A的状态，确认A进入WAITING后不再继续执行后面的代码。
    private static void demo23(){
        Thread A = new Thread(()->{
            synchronized(obj){
                try{
                    obj.wait();
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
                System.out.println("wait后的代码");
            }
        });
        Thread B = new Thread(()->{
            System.out.println("A的状态：" + A.getState());
        });

        A.start();
        B.start();
    }
// 24. 使用notify()唤醒等待线程
// 在上一题基础上，让线程B获取同一把锁后调用notify()。
// 观察A被唤醒后的状态以及它是否会立即继续执行。
    /*怎么叫被唤醒后是否会立即执行，这怎么观察得到啊？只能debug调试还是根据输出判断？
    * 首先A在wait期间是一个WAITING状态，被唤醒但没有立刻执行的话就会出现BLOCKED状态
    * 捕获到即可*/
    //A会立刻获取到锁，因为B线程只有notify操作，等于把A唤醒的同时，B就结束了。
    //所以A不会被阻塞，为了观察这一现象。人为的让B唤醒A以后，继续执行其他操作例如输出循环
    private static void demo24(){
        //或者就让C线程不跟A,B用同一把锁。然后一直观察A的状态，循环重复输出A的状态
        //如果A被唤醒了，那就是从Waiting到RUN或者BLOCKED,如果能检测到A有BLOCKED状态
        //说明没有立刻执行，因为没有立刻获取到锁
        //很奇怪，B的操作在同步代码块里，按理来说是可以捕获到A的，
        // 难道是因为线程C有输出操作没有精准捕获到A阻塞的那一秒吗？
        //只能在B的同步代码块中，唤醒A以后多睡眠一会强制让A阻塞看看，验证
        //yes!yes,非常成功
        //A的状态：RUNNABLE
        //A的状态：BLOCKED
        //A的状态：RUNNABLE
        //A的状态：TERMINATED
        Thread A  = new Thread(()->{
            synchronized(obj){
                try{
                    obj.wait();

                }catch(InterruptedException e){
                    e.printStackTrace();
                }
            }
        });
        Thread B = new Thread(()->{
            synchronized(obj){
                obj.notify();
//                for(int i = 0; i < 10; i++){
//                    System.out.println(i);
//                }
                try{
                    Thread.sleep(3000);
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
            }
        });

        //优化计时写法，学了gpt的提醒还可以把重复状态过滤掉，这就是我之前想做的！
        Thread C = new Thread(()->{
        long end = System.currentTimeMillis() + 5000;
        Thread.State lastState = null;
            while(System.currentTimeMillis() < end){
                Thread.State currentState = A.getState();
                if(currentState != lastState){
                    System.out.println("A的状态：" + currentState);
                    lastState = currentState;
                }
            }

        });

        C.start();
        A.start();
        B.start();

    }
// 25. 理解wait()会释放锁
// 让线程A获取锁后调用wait()，让线程B随后尝试进入同一个同步代码块。
// 通过输出证明A进入WAITING后，B可以获得原本由A持有的锁。
    /*在B里输出A的WAITING状态*/
    private static void demo25(){
        Thread A = new Thread(()->{
            synchronized(obj){
                System.out.println("A获取到锁");
                try{
                    obj.wait();
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
                System.out.println("A睡中被唤醒");
            }
        });
        //思考这个唤醒怎么写，首先，等待和唤醒都是在同步代码块中的写法
        //因为等待和唤醒的都是同步中的交互。那有个问题一直没获取到锁的话就无法进入同步代码块
        //又怎么样才能执行唤醒操作呢，重点原因！->wait会释放锁，不像sleep
        Thread B = new Thread(()->{
            synchronized(obj){
                System.out.println("B获取到锁并且A的状态是：" + A.getState());
//                if(A.getState() != Thread.State.WAITING){
//                    obj.notify();
//                    System.out.println("B唤醒A,也说明A在WAITING状态，B是能获取到锁的。wait()会释放锁对象");
//                }

            }
        });

        A.start();
        B.start();
    }

// 26. 理解被notify后的重新竞争
// 让A调用wait()进入等待，B调用notify()后继续持有锁一段时间。
// 观察A被通知后是否能够立刻执行，记录A可能经历的状态变化。
    /*A当然不能立即执行，而是BLOCKED阻塞状态，因为B在同步代码块中，还在持有锁
    ，等待B线程同步代码块执行完成才能获得锁*/
    private static void demo26(){
        Thread A = new Thread(()->{
            synchronized(obj){
                try{
                    obj.wait();
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
            }
        }, "demo26-A线程");

        Thread B = new Thread(()->{
            synchronized(obj){
                obj.notify();
                try{
                    Thread.sleep(5000);
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
            }
        });
        A.start();
        B.start();

        threadTrace(A);
    }
    //在想观察状态这个这几个方法老用，不如封装成一个方法，传要检测状态的线程即可
    private static void threadTrace(Thread t){//连续检测10s
        Thread Trace = new Thread(()-> {
            long end = System.currentTimeMillis() + 10000;
            Thread.State lastState = null;
            while(System.currentTimeMillis() < end){
                Thread.State state = t.getState();
                if(state != lastState){
                    System.out.println(t.getName() + "的状态：" + state);
                    lastState = state;
                }
            }
        });
        Trace.start();
    }

// 27. 使用wait(long)进入TIMED_WAITING
// 创建等待线程调用wait(3000)，不创建主动唤醒线程。
// 观察线程是否会在超时时间结束后自动恢复执行。
    private static void demo27(){
        Thread A = new Thread(()->{
            synchronized(obj){
                try{
                    obj.wait(3000);
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
                System.out.println("恢复执行");
            }
        });
        A.start();
    }

// 28. 比较wait()与wait(long)
// 分别让两个线程调用wait()和wait(3000)，观察它们进入的状态。
// 思考为什么一个可以自动结束等待，而另一个必须依赖通知。

    private static void demo28(){
        /*因为一个是无限等待，只能唤醒。一个是计时等待，没有唤醒。自己也能醒*/
        Thread t1 = new Thread(()->{
            synchronized(obj) {
                try {
                    obj.wait();

                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                System.out.println("wait()结束？");
            }
        });
        t1.start();
        Thread t2 = new Thread(()->{
            synchronized(obj) {
                try{
                    obj.wait(3000);
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
                System.out.println("wait(3000)结束");
            }
        });
        t2.start();

    }
// 29. 验证wait(long)可以提前结束
// 让线程A调用wait(5000)，线程B在较短时间后调用notify()。
// 观察A是否一定等待满5秒，并正确描述“等待结束”的原因。
    /*因为在自然睡醒之前被唤醒了*/
    private static void demo29(){
        Thread A = new Thread(()->{
            synchronized(obj){
                long begin = System.currentTimeMillis();
                try{
                    obj.wait(5000);
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
                long end = System.currentTimeMillis();
                System.out.println("等了：" + (end - begin) + "ms");
            }
        });
        Thread B = new Thread(()->{
            synchronized(obj){
                try{
                    Thread.sleep(2000);
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
                obj.notify();
            }
        });
        A.start();
        B.start();
    }
// 30. 生产者消费者基础模型
// 用一个共享int表示生产资料数量：生产者不断增加，消费者没有资料时wait()。
// 生产者生产后notify()，消费者被唤醒后消费资料，要求两个线程共享同一份数据。
    static int num = 0;
    private static void demo30(){
        //共享int，两个线程共享同一份数据。int是值传递，
        // 如果定义成局部变量，无法将线程内部对值的修改传递回来
        //如果考虑在Runnable的实现类里共享，那run方法又无法区分开
        //所以要么把这个int包装到一个单独的类里，作为一个对象的成员变量，或者类的成员变量来访问
        //线程就自定义用构造方法的参数来接收这个类对象或类的成员变量int
        //要么直接写在当前这个类里做成员变量，然后当前方法匿名内部类重写线程，也可以访问到这个变量

        Thread pro = new Thread(()->{
            for(int i = 0; i < 10; i++){
                synchronized(obj){
                    //没有看到交错运行的效果，所以等一下
                    try{
                        Thread.sleep(1000);
                    }catch(InterruptedException e){
                        e.printStackTrace();
                    }
                    System.out.println("生产者生产第：" + ++num);
                    obj.notify();
                }
            }
        });
        Thread con = new Thread(()->{
            while(true){
                synchronized(obj){
                    if(num == 0){
                        try{
                            obj.wait();
                        }catch(InterruptedException e){
                            e.printStackTrace();
                        }
                    }
                    //开始消费
                    System.out.println("消费者消费第:" + num--);
                }
            }

        });

        pro.start();
        con.start();
    }

// 31. 修正消费者的等待条件
// 在生产者消费者模型中，消费者不能只使用if判断一次是否有数据。
// 使用while重新检查条件，避免被唤醒后条件已经不满足仍继续消费。
    /*这段题目要求是什么意思？
    * if换成while能理解，因为以防开始没有资源可消耗，线程进行时又有资源可以消耗的情况
    * 需要反复判断，不能if只判断一次。会错失后续有资源的情况
    *
    * 消费者避免被唤醒后条件已经不满足仍然继续消费？啥意思，
    * 先分析消费者和生产者模型，同步代码块中进行wait和notify
    * wait会在同步块中让出同步锁，消费者如果被唤醒，就是在之前wait后的位置开始继续运行
    * 被唤醒后，条件已不满足？不存在这种情况，while,if都不能避免这种情况
    * 这种情况需要在另一个线程唤醒自己的地方做判断，或者wait这种暂停在while体之外
    *
    * nonono完全理解错意思了，意思是在while中wait让出锁对象以后
    * 等到再次被唤醒，还在while里的wait后，继续运行会进入下一次的循环判断
    * */
    static int count31 = 0;
    private static void demo31(){
        Thread producer = new Thread(){
            @Override
            public void run(){
                synchronized(obj){
//                    while(count != 0){//有资料就不生产
                    for(int i = 0; i < 10; i++){
//                        try{
////                            obj.wait();//这里要求被唤醒了睡完了，再进来还得再判断？
//                            //那就得判断条件在wait之后？
////                            while(count31){
////
////                            }
//                        }catch(InterruptedException e){
//                            e.printStackTrace();
//                        }
                        System.out.println("生产：" + ++count31);
                        obj.notify();
                    }
//                    }

                }
            }

        };
        Thread consumer = new Thread(){
            @Override
            public void run(){
                synchronized(obj){
                    while(count31 == 0){
                        try{
                            obj.wait();
                        }catch(InterruptedException e ){
                            e.printStackTrace();
                        }
                    }
                    while(count31 != 0){
                        System.out.println("消费者消费：" + count31--);

                    }

                }
            }
        };

        producer.start();
        consumer.start();
    }

// 32. 设计生产结束条件
// 生产者累计生产指定数量后自然结束，消费者在没有资料且生产已经结束时也应退出。
// 要求增加一个“生产是否结束”的共享状态，并通过锁保证判断和修改安全。
    /*思考一个问题，生产是否结束，作为一个共享状态，要求生产者累计生产指定数量后自然结束。
    * 那这个生产结束的状态影响到还没消费完的消费者怎么办？
    * 这一节的题目都出的很奇怪感觉很不合理，或者说描述不清晰有歧义
    * 我知道了，应该是一个或者的关系，判断生产者的状态是否结束且没有生产资料了就结束消费者*/
    static int info = 0;
    static boolean statu = true;
    private static void demo32(){
        Thread pro = new Thread(()->{
            synchronized(obj){
                int count = 0;//统计生产次数，大于10停止
                while(statu){
                    try{//想让生产者和消费者尽量交替进行
                        obj.wait(50);
                    }catch(InterruptedException e){
                        e.printStackTrace();
                    }
                    System.out.println("生产：" + ++info);
                    obj.notify();

                    if(++count == 10){
                        statu = false;
                    }
                }
            }
        });

        Thread con = new Thread(()->{
            synchronized(obj){
                while(statu == true || info != 0){//生产状态判断是否结束，一个是根据生产状态的资源共享
                    if(info == 0){
                        try{
                            obj.wait();
                        }catch(InterruptedException e){
                            e.printStackTrace();
                        }
                    }
                    System.out.println("消费： " + info--);

                }
                //自然结束
            }
        });

        pro.start();
        con.start();
    }

// 33. 综合观察线程状态
// 设计程序观察目标线程经历NEW、RUNNABLE、TIMED_WAITING、BLOCKED、WAITING等状态。
// 使用其他线程观察目标线程，并在注释中写出每种状态产生的原因。
    private static void demo33(){
        Thread A = new Thread(() -> {
            System.out.println("线程：" + Thread.currentThread().getName() );
            //RUNNABLE
            synchronized(obj){//锁被抢就BLOCKED
                try{
                    obj.wait(1000);//TIMED_WAITING产生原因
                    obj.wait();//WAITING
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
            }
        }, "A");
//        Thread C = new Thread(() ->{
//            synchronized(obj){
//                try{
//                    Thread.sleep(1000);
//                }catch(InterruptedException e){
//                    e.printStackTrace();
//                }
//            }
//        });


        Thread B = new Thread(() -> {
            long end = System.currentTimeMillis() + 10000;
            Thread.State lastState = null;
            while(System.currentTimeMillis() < end){
                Thread.State state = A.getState();
                if(state != lastState){
                    System.out.println("A线程的状态：" + state);
                    lastState = state;
                }
            }

        }, "B");

        //安排一个线程和A抢锁
        Thread C = new Thread(() -> {
            synchronized(obj){
                System.out.println("负责抢A的锁");
                try{
                    Thread.sleep(1000);
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
            }
        });

        B.start();//观察A的状态
        C.start();//和A抢锁
        try{
            Thread.sleep(100);//稍微停一下，不然捕获不到A的NEW状态
        }catch(InterruptedException e){
            e.printStackTrace();
        }
        A.start();


    }

// 34. 判断线程何时真正终止
// 创建一个执行完run()后自然结束的线程，使用另一个线程观察其状态。
// 输出TERMINATED并说明“线程终止”与“线程对象仍然存在”之间的区别。
    private static void demo34(){
        Thread A = new Thread(()->{
            for(int i = 0; i <10; i++){
                System.out.println(i);
            }
        });
        Thread B = new Thread(()->{
            long end = System.currentTimeMillis() + 10000;
            Thread.State lastState = null;
            while(System.currentTimeMillis() < end){
                Thread.State state = A.getState();
                if(lastState != state){
                    System.out.println("A线程的状态：" + state);
                    lastState = state;
                }

            }
        });
        A.start();
        B.start();
        /*TERMINATED线程终止就是线程运行结束了，线程对象存在指的是线程对象创建了但不一定开始运行了*/
    }
    /*准确的表达：
    * 线程终止： 指线程的执行生命周期结束，不再执行任务
    * Thread对象:是用于表示和操作该线程的普通Java对象,线程终止后对象仍可能存在，只要还有引用指向他
    * ，就可以继续访问其状态等信息*/

// 35. 综合线程同步与状态
// 两个线程竞争同一把锁：A持锁sleep，B等待锁；A释放锁后B继续执行。
// 使用第三个线程观察B的状态变化，并写出B从RUNNABLE到BLOCKED再到RUNNABLE的原因。
    /*原因：线程刚启动就是可运行的RUNNABLE状态
    * 没拿到锁，等待锁对象就是BLOCKED状态
    * A运行完释放锁，B拿到了就是RUNNABLE
    * B的run执行完了就是TERMINATED*/
    private static void demo35(){
        Thread A = new Thread(()->{
            synchronized(obj){
                try{
                    Thread.sleep(1000);
                }catch(InterruptedException e){
                    e.printStackTrace();
                }
            }
        });
        Thread B = new Thread(()->{
            synchronized(obj){
                System.out.println("B得到锁");
            }
        });
        Thread C = new Thread(()->{
            long end = System.currentTimeMillis() + 10000;
            Thread.State lastState = null;
            while(System.currentTimeMillis() < end){
                Thread.State state = B.getState();
                if(state != lastState){
                    System.out.println("B的状态： " + state);
                    lastState = state;
                }
            }
        });

        C.start();
        A.start();
        B.start();
    }

    public static void main(String[] args) {
//        demo01();
//        demo02();
//        demo03();
//        demo04();
//        demo05();
//        demo06();
//        demo07();
//        demo08();
//        demo09();
//        demo10();

//        demo11();
//        demo12();
//        demo13();
//        demo14();
//        demo15();
//        demo16();
//        demo17();
//        demo18();
//        demo19();
//        demo20();

//        demo21();
//        demo22();
//        demo23();
//        demo24();
//        demo25();
//        demo26();
//        demo27();
//        demo28();
//        demo29();
//        demo30();
//        demo31();
//        demo32();
//        demo33();
//        demo34();
        demo35();
    }
}
